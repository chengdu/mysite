The Lua debugger for Speare code editor have moved to here: 
http://www.sevenuc.com/download/lua_debugger.tar.gz


