    ___ _       ____ __
   /   | |     / / //_/
  / /| | | /| / / ,<   
 / ___ | |/ |/ / /| |  
/_/  |_|__/|__/_/ |_|  
                      
AWK Debugger v0.0.2
(c) 2021 http://sevenuc.com
- - - - - - - - - - - - - - - - - - - - - - - - - - - - - -

This is the AWK remote debugger for Speare code editor:
http://www.sevenuc.com/en/speare.html

Package source: 
---------------
http://www.sevenuc.com/debuggers/awk_debugger.zip

Package content:
----------------

awk_debugger
|____gawk           # the debugger (872KB)
|____readme.txt     # readme for this package, this file


Start Awk debugging session:
----------------------------

1. Launch gawk with option "-D" from Terminal.app.
   # environment variables (optional):
   $ export AWK_PORT_NUMBER=4321  #debug port number
   $ export AWKPATH=/directory/to/find/source/files/ 
   $ export AWKLIBPATH=/directory/to/find/libraries/
   # full filename for startup script
   $ ./gawk -D -f /Users/name/Desktop/test/calendar.awk

2. Select the Awk source code file in Speare code editor.
   Add breakpoint by click the line number of the function that
   you want to stop there or inspect that function.

3. Syntax checking and run the Awk source code file.
   → select main menu "Debug"  →  "Start Debug".


Note:
--------
a. The optional port number must be as same as the settings of
   Speare code editor.

b. AWKPATH environment variable must be properly set, All Awk 
   source code files and data files must be in the workspace of
   Speare code editor before start a debug session, because 
   macOS app can't be allowed to access files outside of its 
   sandbox.


Compatibility:
--------------

This AWK debugger implemented as a patched version of gawk 
version 5.1.0, it should be compatible with the respected 
"Unix awk" by Mr. Brian Kernighan, i.e. "The One True Awk", and 
the excellent Mawk by Mr. Mike Brennan. You can enjoy debugging 
AWK source code under the lightweight debugging environment of 
Speare code editor, for simple command line scripts, complex 
utility, or big programs.



Jul 30 2021


