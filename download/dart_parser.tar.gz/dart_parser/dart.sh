#!/bin/bash

cwd=$(cd "$(dirname "$0")"; pwd)
path=${cwd}/dart-ctags
# call dart-ctag to parse source code
"$path" --line-numbers $1

