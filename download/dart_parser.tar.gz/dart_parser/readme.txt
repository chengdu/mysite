   ____
  / __/ __  ___ ___  ___ ___
  _\ \/ _ \/ -_) _ `/ __/ -_)
 /___/ .__/\__/\_,_/_/  \__/
    /_/
Speare v1.2.40
Copyright (c) 2020 sevenuc.com. All rights reserved.

This is the Dart code parser that used to parse and index 
Dart source code files in Speare code editor. Please copy
dart.sh and dart-ctags to:
~/Library/Application Scripts/com.sevenuc.SpeareHelper/parsers

Source: http://sevenuc.com/en/Speare.html


