#!/bin/sh
#kill lua process when it wasn't exited elegantly
port=7176
if [ $# -eq 1 ]
 then port=$1
fi
lsof -iTCP -sTCP:LISTEN -n -P | grep $port | awk '{print $2}'| xargs kill -9

