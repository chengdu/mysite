-- Speare Debug Server
-- version: 1.0
-- http://sevenuc.com/en/Speare.html
socket = require "socket"
_G["socket"] = socket
require "sds"
debugger.listen('*', 7176)

