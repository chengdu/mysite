#!/bin/bash

# use -> /usr/local/bin/node
if ! [[ $PATH == *"/usr/local/bin"* ]]; then
  export PATH=/usr/local/bin:$PATH
fi

cwd=$(cd "$(dirname "$0")"; pwd)
path=${cwd}/formatter.js
# check if node is installed
ver=$(which node)
if ! [[ ${#ver} -eq 0 ]] && ! [[ $ver == *"command not found"* ]]; then
  node "$path" $1
fi

