#!/bin/bash

# use -> /Users/yeung/Public/Dart/dart-sdk/bin/dartfmt
if ! [[ $PATH == *"/Users/yeung/Public/Dart/dart-sdk/bin"* ]]; then
  export PATH=/Users/yeung/Public/Dart/dart-sdk/bin:$PATH
fi

cwd=$(cd "$(dirname "$0")"; pwd)
# check if dartfmt is installed
ver=$(which dartfmt)
if ! [[ ${#ver} -eq 0 ]] && ! [[ $ver == *"command not found"* ]]; then
  dartfmt $1
fi

