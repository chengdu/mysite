#!/bin/bash

# use -> ~/.cargo/bin/rustfmt
if ! [[ $PATH == *"~/.cargo/bin"* ]]; then
  export PATH=~/.cargo/bin:$PATH
fi

cwd=$(cd "$(dirname "$0")"; pwd)
# check if rustfmt is installed
ver=$(which rustfmt)
# error: 'rustfmt' is not installed for the toolchain xxx
# rustup component add rustfmt --toolchain xxx
if ! [[ ${#ver} -eq 0 ]] && ! [[ $ver == *"command not found"* ]]; then
  rustfmt $1
  cat $1
fi

