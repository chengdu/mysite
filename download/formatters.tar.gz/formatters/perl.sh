#!/bin/bash

cwd=$(cd "$(dirname "$0")"; pwd)
path=${cwd}/perltidy.pl
perl "$path" $1

