#!/bin/bash

cwd=$(cd "$(dirname "$0")"; pwd)
path=${cwd}/shell_formatter.py
python "$path" $1

