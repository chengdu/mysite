#!/bin/bash

# use -> /Users/henry/bin/tcl/bin/tcl
if ! [[ $PATH == *"/Users/henry/bin/tcl/bin"* ]]; then
  export PATH=/Users/henry/bin/tcl/bin:$PATH
fi

cwd=$(cd "$(dirname "$0")"; pwd)
path=${cwd}/reformat.tcl
# check if Tcl is installed
ver=$(which tcl)
if ! [[ ${#ver} -eq 0 ]] && ! [[ $ver == *"command not found"* ]]; then
  tcl "$path" -indent $2 $1
fi

