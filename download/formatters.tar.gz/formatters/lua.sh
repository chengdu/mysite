#!/bin/bash

cwd=$(cd "$(dirname "$0")"; pwd)
path=${cwd}/lua_beautifier.pl
perl "$path" < $1

