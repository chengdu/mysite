   ____
  / __/ __  ___ ___  ___ ___
  _\ \/ _ \/ -_) _ `/ __/ -_)
 /___/ .__/\__/\_,_/_/  \__/
    /_/
Speare v1.2.40
Copyright (c) 2020 sevenuc.com. All rights reserved.

This package contains various code formatter that used to
indent and format code block for Speare code editor.

Source: http://www.sevenuc.com/download/formatters.tar.gz

Please put the uncompressed folder under the following
directory and ensure the shell scripts are executable:
/Users/name/Library/Application Scripts/com.sevenuc.SpeareHelper/


The rule of the formatters is:
Speare code editor will give up formatting if there's 
something printed in stderr or nothing printed in stdout 
otherwise anything printed in stdout will be used to 
replace the selected code block.



