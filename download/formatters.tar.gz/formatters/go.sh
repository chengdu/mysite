#!/bin/bash

# use -> /usr/local/go/bin/gofmt
if ! [[ $PATH == *"/usr/local/go/bin"* ]]; then
  export PATH=/usr/local/go/bin:$PATH
fi

cwd=$(cd "$(dirname "$0")"; pwd)
# check if gofmt is installed
ver=$(which gofmt)
if ! [[ ${#ver} -eq 0 ]] && ! [[ $ver == *"command not found"* ]]; then
  #gofmt -tabwidth=$2 $1
  gofmt $1
fi

