#!/bin/bash

cwd=$(cd "$(dirname "$0")"; pwd)
path=${cwd}/formatter.rb
ruby -W0 "$path" -s $2 $1

