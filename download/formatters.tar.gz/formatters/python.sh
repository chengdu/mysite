#!/bin/bash

cwd=$(cd "$(dirname "$0")"; pwd)
path=${cwd}/pindent.py
python "$path" -r -s $2 -t $2 $1

