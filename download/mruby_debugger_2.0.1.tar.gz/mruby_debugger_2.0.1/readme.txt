                ____ 
  __ _  _______/ / / 
 /  ' \/ __/ _  / _ \
/_/_/_/_/  \_,_/_.__/

mruby Remote Debugger
https://mruby.org
Copyright (c) 2019 sevenuc.com
All rights reserved.

This is the mruby remote debugger for Speare code editor:
http://www.sevenuc.com/en/speare.html

Package source:
http://sevenuc.com/download/mruby_debugger_2.0.1.tar.gz


1. Install mruby debugging server

   a. Download mruby from https://github.com/mruby/mruby
      mruby-2.0.1.tar.gz (518KB)

   b. Compile mruby and replace mrdb under bin directory with the
      corresponding version in this package.

2. Configuring Speare

   Launch Speare and select "Extra" panel of Preferences and then 
   check on "Enable mruby debugging". Please remember to turn the 
   option off when switching to debugging common Ruby applications.

3. Debug Session Start

   Click "Start" button on the debug toolbar of Speare.
   Add breakpoint, step in, step out, step next, ...


23 Oct 2019






