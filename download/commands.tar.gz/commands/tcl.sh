#!/bin/bash
# use -> /Users/yeung/Tcl/8.5.9/bin/tcl
if ! [[ $PATH == *"/Users/yeung/Tcl/8.5.9/bin"* ]]; then
  export PATH=/Users/yeung/Tcl/8.5.9/bin:$PATH
fi
tcl $@

