1. Please put this directory under:
/Users/username/Library/Application Scripts/com.sevenuc.SpeareHelper/

2. Please run the following command to make the shell entries executable:
chmod 755 *
