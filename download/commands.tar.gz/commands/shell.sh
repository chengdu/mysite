#!/bin/bash

# use -> /usr/local/bin/fossil
if ! [[ $PATH == *"/usr/local/bin"* ]]; then
  export PATH=/usr/local/bin:$PATH
fi

$@



