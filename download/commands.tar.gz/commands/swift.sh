#!/bin/bash

#1: full path of current file
#2: command (build, run, clean)
#3: build folder
#4: executable (required)
#5: arguments (ignored)

binary=$4
buildfolder=$3  #/full/path/of/your/project/DerivedData/Build

if [[ $2 == *"build"* ]]; then
  swift build --build-path $buildfolder
fi

if [[ $2 == *"run"* ]]; then
  swift run --build-path $buildfolder $binary # [args]
fi
    
if [[ $2 == *"clean"* ]]; then
  rm -rf $buildfolder/*.* # clean build folder
fi


