#!/bin/bash
python3 $@
