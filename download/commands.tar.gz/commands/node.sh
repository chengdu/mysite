#!/bin/bash
# use -> /Users/yeung/node/10.12.0/bin/node
if ! [[ $PATH == *"/Users/yeung/node/10.12.0/bin"* ]]; then
  export PATH=/Users/yeung/node/10.12.0/bin:$PATH
fi
node $@
