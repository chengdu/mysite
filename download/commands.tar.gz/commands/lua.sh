#!/bin/bash
# use -> /Users/yeung/Lua/5.1.4/bin/lua
if ! [[ $PATH == *"/Users/yeung/Lua/5.1.4/bin"* ]]; then
  export PATH=/Users/yeung/Lua/5.1.4/bin:$PATH
fi
lua $@

