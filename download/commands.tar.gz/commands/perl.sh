#!/bin/bash
perl $@
