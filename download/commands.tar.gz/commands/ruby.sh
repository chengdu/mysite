#!/bin/bash
ruby $@
