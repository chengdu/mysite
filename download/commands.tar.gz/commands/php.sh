#!/bin/bash
# use -> /usr/local/php-7.3.28/bin/php
if ! [[ $PATH == *"/usr/local/bin"* ]]; then
  export PATH=/usr/local/php-7.3.28/bin:$PATH
fi
php $@
