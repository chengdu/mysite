demo code for the following document: 
http://sevenuc.com/download/the_issue.pdf

source: 
http://sevenuc.com/download/the_issue.tar.gz





