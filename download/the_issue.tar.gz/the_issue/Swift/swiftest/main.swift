//
//  main.swift
//  swiftest
//
//  Created by MaaJi Loeng on 12/7/2017.
//

import Foundation

protocol IBaseParser {
    var name: String {get}
}

protocol IBaseParser2: IBaseParser {
    var name2: String {get}
}

//===
class CParser: IBaseParser {
    var name: String { return "CParser" }
}

class PerlParser: CParser{
    override var name: String { return "PerlParser" }
}

//===
class HaskellParser: IBaseParser2{
    var name: String { return "HaskellParser name1" }
    var name2: String { return "HaskellParser name2" }
}

//===
class Perl6Parser: PerlParser, IBaseParser2{
    var haskell: HaskellParser?
    override init() {
        self.haskell = HaskellParser()
    }
    var name2: String {
        if let id = haskell{
            return id.name2
        }else{
            return "Perl6Parser"
        }
    }
}

let parser = Perl6Parser()
print("1: \(parser.name)")
print("2: \(parser.name2)")

