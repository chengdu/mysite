package com.sevenuc.oop;
import com.sevenuc.oop.CParser.*;

public class PerlParser extends CParser {
   public String name(){
      return "PerlParser";
   }
}

