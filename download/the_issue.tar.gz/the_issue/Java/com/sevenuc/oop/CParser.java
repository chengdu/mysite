package com.sevenuc.oop;
import com.sevenuc.oop.IBaseParser.*;

public class CParser implements IBaseParser {
   public String name(){
      return "CParser";
   }
}

