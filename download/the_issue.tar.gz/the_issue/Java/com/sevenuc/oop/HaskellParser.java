package com.sevenuc.oop;
import com.sevenuc.oop.IBaseParser2.*;

public class HaskellParser implements IBaseParser2 {
   public String name(){
      return "HaskellParser name";
   }
   public String name2(){
      return "HaskellParser name2";
   }
}


