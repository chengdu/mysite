package com.sevenuc.oop;
import com.sevenuc.oop.Perl6Parser.*;

public class IssueDemo{
	public static void main(String[] args){
	      Perl6Parser p = new Perl6Parser();
	      System.out.println("1: " + p.name());
	      System.out.println("2: " + p.name2());
	}
}

