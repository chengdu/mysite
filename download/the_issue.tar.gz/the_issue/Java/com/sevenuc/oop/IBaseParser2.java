package com.sevenuc.oop;
import com.sevenuc.oop.IBaseParser.*;

public interface IBaseParser2 extends IBaseParser {
    String name2();
}

