package com.sevenuc.oop;

public interface IBaseParser {
    String name();
}

