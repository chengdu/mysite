package com.sevenuc.oop;
import com.sevenuc.oop.PerlParser.*;
import com.sevenuc.oop.HaskellParser.*;

public class Perl6Parser extends PerlParser {
   private HaskellParser haskell;
   Perl6Parser(){
      this.haskell = new HaskellParser();
   }

   public String name2(){
      if(haskell != null) return haskell.name2();
      return "Perl6Parser";
   }
   
}
