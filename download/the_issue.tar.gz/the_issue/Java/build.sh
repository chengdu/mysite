rm -rf com/sevenuc/oop/*.class
javac com/sevenuc/oop/*.java
java com.sevenuc.oop.IssueDemo













