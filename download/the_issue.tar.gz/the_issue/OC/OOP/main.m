//
//  main.m
//  OOP
//
//  Created by MaaJi Loeng on 12/7/2017.
//

#import <Foundation/Foundation.h>

@protocol IBaseParser <NSObject>
@required
- (NSString *)name;
@end
@protocol IBaseParser2 <IBaseParser>
@required
- (NSString *)name2;
@end

//===
@interface CParser: NSObject <IBaseParser>
@end
@implementation CParser
- (NSString *)name{
    return @"CParser";
}
@end
@interface PerlParser: CParser
@end
@implementation PerlParser
- (NSString *)name{
    return @"PerlParser";
}
@end

//===
@interface HaskellParser:NSObject <IBaseParser2>
@end
@implementation HaskellParser
- (NSString *)name{
    return @"HaskellParser name";
}
- (NSString *)name2{
    return @"HaskellParser name2";
}
@end

//===
@interface Perl6Parser: PerlParser <IBaseParser2>{
    HaskellParser *haskell;
}
@end
@implementation Perl6Parser
-(id)init{
    self = [super init];
    if(self){
        haskell = [[HaskellParser alloc] init];
    }
    return self;
}
- (NSString *)name{
    return [super name];
}
- (NSString *)name2{
    // fetch own's implement or HaskellParser's implement?
    if(haskell) return [haskell name2];
    else return @"Perl6Parser";
}
@end


int main(int argc, const char * argv[]) {
    @autoreleasepool {
        Perl6Parser *parser = [[Perl6Parser alloc] init];
        NSLog(@"1: %@", [parser name]);
        NSLog(@"2: %@", [parser name2]);
    }

    return 0;
}
